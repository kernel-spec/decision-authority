# VSF / Decision Authority Artifacts Bundle

Generated: 2026-02-22

This zip includes:
- Custom GPT system prompts (copy/paste)
- GitHub Actions CI/CD workflows
- Cloudflare Workers wrangler configs (stage/prod)
- D1 migrations (including usage_ledger + system_state)
- Minimal docs templates
- Proof PDF: assets/proof/board-ready-micro-cases.pdf
